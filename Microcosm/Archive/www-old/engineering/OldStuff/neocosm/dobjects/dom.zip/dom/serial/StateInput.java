/****************************************************************************

    Copyright (c) 1997 Scott B. Lewis
    All Rights Reserved

    This software may not be copied or disclosed.

    $Archive: /dom/serial/StateInput.java $
    $Revision: 1 $
    $Date: 1/6/98 10:00p $
    $Author: Sbl $

    Todo:

****************************************************************************/

package dom.serial;

import java.io.DataInput;


/**
 * Interface for state restoring from state input stream.
 * @author Scott Lewis
 */
public interface StateInput extends DataInput {

  // TODO
}

