package dom.util;

public class TOSViolationException extends DOMException {}

