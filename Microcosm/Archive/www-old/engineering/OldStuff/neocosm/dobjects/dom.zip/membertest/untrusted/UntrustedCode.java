package membertest.untrusted;

import membertest.trusted.TrustedCode;

public class UntrustedCode
{
    public UntrustedCode(TrustedCode trust)
    {
        System.out.println("membertest.untrusted.UntrustedCode.<init>");
        // Try to call the method here.
        try {
            trust.bogusMethod();
        } catch (Throwable e) {
            System.out.println("Call of bogusMethod on "+trust+" failed with exception "+e);
            e.printStackTrace();
        }
    }
}