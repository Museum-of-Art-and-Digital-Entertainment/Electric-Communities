package dom.beans;

import sun.beanbox.BeanBox;

import java.net.*;
import java.io.Serializable;

import dom.id.*;
import dom.session.*;

/**
 * @author Scott Lewis
 */
public class BeanBoxView extends ClientView
{
    BeanBox myBeanBox;
    
    public BeanBoxView(SessionViewID id)
    {
        super(id);
    }
    
    public void setBeanBox(BeanBox box)
    {
        myBeanBox = box;
    }

    public void createDBean(Serializable dBean) 
        throws Exception
    {
        super.createDObject(null, DObjectID.makeNewID(), getID(), null, "dom.beans.BeanDObject", dBean, true);
    }
    
    public void addBeanToBeanBox(BeanDObject object)
    {
        myBeanBox.addBean(object.getBean(), object.getBeanLabel(), object.getBeanName(), object.getInitLocX(), object.getInitLocY());
    }
    
    // XXX hack to connect to locally hosted view
    public void joinLocalHostGroup() throws Exception
    {
        this.joinGroupAtURL("http://localhost:6000");
    }
    
    public void joinGroupAtURL(String theURL) throws Exception
    {
        this.joinGroup(SessionViewID.makeNewID(theURL));
    }

    protected BaseFacet getViewFacet(DObject requestor, String request, Object data)
    {
        try {
            if ("viewFacet".equals(request)) {
                return new DirectViewAccessFacet(requestor, this);
            }
            return null;
        } catch (Exception e) {
          return null;
        }
    }

}