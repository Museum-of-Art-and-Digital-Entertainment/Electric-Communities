package dom.container;

import dom.util.DOMException;

public class ContainerException extends DOMException {}