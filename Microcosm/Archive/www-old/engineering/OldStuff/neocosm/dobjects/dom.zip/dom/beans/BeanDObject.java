package dom.beans;

import dom.id.*;
import dom.session.*;

import java.net.URL;
import java.io.*;

import dom.facet.NullFacetException;

/**
 * A DObject subclass that provides a wrapper for a DistributedBean instance
 * (some object that implements the DistributedBean interface).
 *
 * @author Scott Lewis
 */
public class BeanDObject extends DBean
{
    // Here is our connection with the local bean box.  We hold onto a separate
    // reference here, because our super class only exposes the ViewDObjectFacet
    BeanBoxView myBeanBoxView;

    /**
     * Public constructor for this DObject.  This is called for both the host
     * and client instance.
     * @param session a ViewDObjectFacet object that defines our local runtime context.
     * If this parameter is null, an InstantiationException is thrown.
     * @param newID a DObjectID that is the new id for this DObject.
     * If this parameter is null, an InstantiationException is thrown.
     * @param homeID a SessionViewID that is the home view id for this DObject
     * If this parameter is null, an InstantiationException is thrown.
     * @param codeBase an URL that identifies the (local or remote) codebase
     * for this DObject.  This parameter may be null.
     * @param params an Object that is used to initialize any subclasses
     * @exception InstantiationException is thrown if any of the critical
     * parameters are null.
     */
    public BeanDObject(ViewDObjectFacet viewFacet, DObjectID myID,
        SessionViewID homeID, URL codebase, Serializable param)
        throws InstantiationException
    {
        super(viewFacet, myID, homeID, codebase, param);
	try {
            DirectViewAccessFacet aViewFacet = (DirectViewAccessFacet) viewFacet.getViewFacet("viewFacet", null);
            if (aViewFacet != null) {
                myBeanBoxView = (BeanBoxView) aViewFacet.getView();
            }
        } catch (Exception e) {
            System.out.println("BeanDObject.<init>.  Failed to get access to view.  No UI available");
        }
    }

    /**
     * This is called by our run queue thread in response to a message from
     * the View
     *
     * @param info the ViewNotifyInfo associated provided by the View when
     * it notifies us we have been activated.
     */
    protected void activated(ViewNotifyInfo info)
    {
        debug("BeanDObject.activated("+info+")");
        if (myBeanBoxView != null) {
            System.out.println("Adding bean to bean box");
            myBeanBoxView.addBeanToBeanBox(this);
        }
        // Tell bean it should activate itself
        super.activated(info);
    }

    /**
     * This is called by our run queue thread in response to a message from
     * the View.
     * In response to this message, we should do any clean up that we would
     * like to have done before we go away as this is the last message we
     * will get from the View.
     *
     * @param info the ViewNotifyInfo associated provided by the View when
     * it notifies us we have been deactivated.
     */
    protected void deactivated(ViewNotifyInfo info)
    {
        debug("BeanDObject.deactivated("+info+")");
        // Tell bean it should deactivate itself
        super.deactivated(info);
    }

    /**
     * Get the state of this DObject for client creation.  In this case, our
     * state is simply the serialized state of the JavaBean we are a wrapper
     * for, so we simply return our JavaBean.  This assumes that the Bean we
     * are a wrapper for implements the Serializable interface (which should
     * be the case anyway by construction).
     *
     * @param id the SessionViewID of the View where we are doing the creation
     * @return Serializable that will be our remote client's initial state
     */
    protected Serializable getStateForClient(SessionViewID id)
    {
        debug("BeanDObject.getStateForClient");
        // Mwuhahaha
        return myBean;
    }    
    
    
   public String getBeanLabel()
   {
        return "DistributedBeanLabel";
   }
   
   public String getBeanName()
   {
        return "DistributedBeanName";
   }
   
   public int getInitLocX()
   {
        return 0;
   }
   
   public int getInitLocY()
   {
        return 0;
   }
   
   public boolean isPresenceClient()
   {
        return super.isClient();
   }
    
}
