package dom.beans;

import dom.id.*;
import dom.session.*;

import java.net.URL;
import java.io.*;

import dom.facet.NullFacetException;

/**
 * A DObject subclass that provides a wrapper for a DistributedBean instance
 * (some object that implements the DistributedBean interface).  This is a minimal
 * wrapper, in that all it does is pass calls on to the bean itself.
 *
 * @author Scott Lewis
 */
public class DBean extends DObject
{
    // Here is the JavaBean object itself.  It must be Serializable,
    // so that we may send its state over the wire.  The DistributedBean
    // interface is a subclass interface of Serializable
    protected DistributedBean myBean;

    /**
     * Constructor for this DObject.  This is called by the creating View
     * for both the host and client presences.
     * 
     * @param session a View object that defines our local runtime context.
     * If this parameter is null, an InstantiationException is thrown.
     * @param newID a DObjectID that is the new id for this DObject.
     * If this parameter is null, an InstantiationException is thrown.
     * @param homeID a SessionViewID that is the home view id for this DObject
     * If this parameter is null, an InstantiationException is thrown.
     * @param codeBase an URL that identifies the (local or remote) codebase
     * for this DObject.  This parameter may be null.
     * @param params an Object that is used to initialize any subclasses
     * @exception InstantiationException is thrown if any of the critical
     * parameters are null.
     */
    protected DBean(ViewDObjectFacet viewFacet, DObjectID myID,
        SessionViewID homeID, URL codebase, Serializable param)
        throws InstantiationException
    {
        super(viewFacet, myID, homeID, codebase, param);
        if (param instanceof DistributedBean) {
            myBean = (DistributedBean) param;
        } else throw new InstantiationException("Bean does not implement DistributedBean interface");
        // Let DistributedBean know about us, so it can use us for sending Closures
        // and etc.
        myBean.setDObject(this);
        debug("DBean.<init>");
    }

    /**
     * This is called by our run queue thread in response to a message from
     * the View
     *
     * @param info the ViewNotifyInfo associated provided by the View when
     * it notifies us we have been activated.
     */
    protected void activated(ViewNotifyInfo info)
    {
        debug("DBean.activated("+info+")");
        // Tell bean it should activate itself
        myBean.activate();
    }

    /**
     * This is called by our run queue thread in response to a message from
     * the View.
     * In response to this message, we should do any clean up that we would
     * like to have done before we go away as this is the last message we
     * will get from the View.
     *
     * @param info the ViewNotifyInfo associated provided by the View when
     * it notifies us we have been deactivated.
     */
    protected void deactivated(ViewNotifyInfo info)
    {
        debug("DBean.deactivated("+info+")");
        // Tell bean it should deactivate itself
        myBean.deactivate();
    }

    /**
     * Get the state of this DObject for client creation.  In this case, our
     * state is simply the serialized state of the JavaBean we are a wrapper
     * for, so we simply return our JavaBean.  This assumes that the Bean we
     * are a wrapper for implements the Serializable interface (which should
     * be the case anyway by construction).
     *
     * @param id the SessionViewID of the View where we are doing the creation
     * @return Serializable that will be our remote client's initial state
     */
    protected Serializable getStateForClient(SessionViewID id)
    {
        debug("DBean.getStateForClient");
        // Mwuhahaha
        return myBean;
    }

    /**
     * Get the JavaBean that we are a wrapper for.
     *
     * @return Object that is our actual JavaBean object
     */
    protected DistributedBean getBean()
    {
        return myBean;
    }

    /**
     * Execute a given closure for this DObject.  This is an override of the
     * DObject.runClosure method.  The override is here so that rather than
     * simply trying to execute every Closure on this class directly, this method
     * first tries to execute the closure on this class (so that client creation
     * and etc. can be done by DObject superclass), and then if that doesn't work,
     * tries to execute the given Closure on the *Bean* for this object.  This
     * makes it very easy for the JavaBean code to send Closures back and forth.
     * It does, however, require that the Bean be careful about *naming* those
     * messages, as it doesn't want to inadvertantly conflict with a message that
     * is handled by the DObject superclass.
     *
     * @param closureToRun the Closure to execute
     * @exception Exception thrown if (e.g.) the Closure cannot be found on either
     * this object nor the JavaBean this is a wrapper for
     */
    protected void runClosure(Closure closureToRun)
        throws Exception
    {
        // For this kind of DObject (Bean), first we will try to execute the
        // closure on the super class DObject (to handle client create messages
        // and etc)
        try {
            super.runClosure(closureToRun);
        } catch (Exception e) {
            debug("Exception "+e+" executing "+closureToRun+" on DBean superclass.  Trying bean directly...");

            // If we get an exception giving this closure to our superclass,
            // give it to our bean!
            closureToRun.executeThisClosure(getBean());
        }
    }

    /**
     * Public version of isClientPresence(), so that arbitrary JavaBean code
     * can query and determine whether it is a client or host DistributedBean.
     *
     * @return true if client presence, false if host
     */
    public boolean isClient()
    {
        return this.isClientPresence();
    }

    /**
     * Interface for DistributedBean objects to query about whether (for a given
     * presence) they are running on a server (no GUI) or a client (has GUI).
     *
     * @return true if running on a server and false if on client
     */
    public boolean isServer()
    {
        try {
            return getSessionView().isServer();
        } catch (NullFacetException e) {
            // Should not happen, but if it does, we'll just print spam
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Utility function to catch exception for delivering Closures to all remote
     * presences.
     *
     * @param aClosure the Closure to deliver to remotes
     * @see DObject#sendClosureToRemotes
     */
    public void sendClosureToRemotes(Closure aClosure)
    {
        try {
            super.sendClosureToRemotes(aClosure);
        } catch (IOException e) {
            // e.printStackTrace();
        }
    }

    /**
     * Catches exception and ignores.
     *
     * @param closure the Closure to deliver to the host
     * @see DObject#sendClosureToHost
     */
    public void sendClosureToHost(Closure closure)
    {
        try {
            super.sendClosureToHost(closure);
        } catch (IOException e) {
                // If this happens, we'll ignore except for spam
                e.printStackTrace();
        }
    }

}
