package membertest;

import membertest.trusted.TrustedCode;
import membertest.untrusted.UntrustedCode;

public class MemberAccessTest {

    public static void main(String args[]) {

        // First create an instance of the trusted class
        TrustedCode myTrusted = new TrustedCode();

        //Then create an instance of UntrustedCode
        UntrustedCode myUntrusted = new UntrustedCode(myTrusted);

    }
}


