package dom.container;

import dom.util.DOMException;

public class ContainableException extends DOMException {}