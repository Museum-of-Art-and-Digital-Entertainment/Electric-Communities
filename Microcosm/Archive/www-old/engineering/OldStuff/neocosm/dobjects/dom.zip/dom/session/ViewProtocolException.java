/****************************************************************************

    Copyright (c) 1997 Scott B. Lewis
    All Rights Reserved

    This software may not be copied or disclosed.

    $Archive: /dom/session/ViewProtocolException.java $
    $Revision: 1 $
    $Date: 1/27/98 8:00p $
    $Author: Sbl $

    Todo:

****************************************************************************/
package dom.session;

import dom.util.DOMException;

/**
 * 
 * @author Scott Lewis
 */
public class ViewProtocolException extends DOMException
{
    // TODO
}

