package dom.beans;

import dom.session.DObject;

import java.io.Serializable;

/**
 * @author Scott Lewis
 */
public interface DistributedBean extends Serializable
{
    public void setDObject(DBean shadow);
    public void activate();
    public void deactivate();
    
}