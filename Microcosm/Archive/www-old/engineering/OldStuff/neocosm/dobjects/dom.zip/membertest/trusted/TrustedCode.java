package membertest.trusted;

public class TrustedCode
{
    public TrustedCode() {
        System.out.println("membertest.trusted.TrustedCode.<init>");
    }

    /**
     * This is the target method.  If declared public, it should be callable
     * by untrusted code.  If declared protected or private it seems like it should be
     * inaccessible, but it seems to be anyway.
     *
     */

    private /* public */ void bogusMethod()
    {
       System.out.println("BOGUS METHOD SUCCESSFULLY CALLED");
    }
}