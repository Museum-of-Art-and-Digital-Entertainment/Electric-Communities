/****************************************************************************

    Copyright (c) 1997 Scott B. Lewis
    All Rights Reserved

    This software may not be copied or disclosed.

    $Archive: /dom/session/CreateClientInfo.java $
    $Revision: 1 $
    $Date: 1/26/98 5:00p $
    $Author: Sbl $

    Todo:

****************************************************************************/
package dom.session;

import dom.id.*;

/**
 * @author Scott Lewis
 */
public class CreateClientResultInfo
{
    // TODO
    // Will contain information relevant to the success/failure of a remote
    // client creation attempt (where, exception info, etc.)
}


